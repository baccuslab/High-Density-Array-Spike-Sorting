function[]=SONVersion()
title='MATLAB SON Library';
st=sprintf('\nMATLAB SON Library: Malcolm Lidierth, King%cs College London 21.01.03\nVersion:1.01\n\nSON Filing system Copyright %c Cambridge Electronic Design 1988-2001\nVersion 6.0',39,169);

h=(msgbox(st,title,'modal'));
